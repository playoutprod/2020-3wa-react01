import React from 'react';
import Square from "./Square"

export default (props) => {
  return (
    <div className="gameBoard">
      <header>
        <div className="playerStatus"><span className="playerName">Player One</span><span className="symbol mdl-button--fab mdl-button--colored">X</span></div>
      </header>
      <div className="board-squares">
          <div className="board-row">
            <Square/>
            <Square/>
            <Square/>
          </div>
          <div className="board-row">
            <Square/>
            <Square/>
            <Square/>
          </div>
          <div className="board-row">
            <Square/>
            <Square/>
            <Square/>
          </div>
      </div>
      <div className="winPopin disabled">
        <div className="message">Congratulations Player 1 ! you've won !!</div>
        <button className="mdl-button mdl-button--colored mdl-button--raised mdl-js-button mdl-js-ripple-effect">Reset</button>
      </div>
    </div>
  );
}
